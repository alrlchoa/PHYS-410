PHYS 410: Project 1 Submission
by Arnold Choa -- 32038144

PDF for answers and write-up can be found in the docs folder:
- CHOA_Project_1_Answers.pdf

Relevant Code will be found in the code folder:
- q2_18.py: Contains code for handling a double-well system
- q2_19.py: Contains modified q2_18.py code for handling n-well systems

Project_1_Questions.pdf is the questionnaire