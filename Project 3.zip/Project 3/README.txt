PHYS 410: Project 3 Submission
by Arnold Choa -- 32038144

PDF for answers and write-up can be found in the docs folder:
- CHOA_Project_3_Answers.pdf

Relevant Code will be found in the code folder partitioned by question

Project_3_Questions.pdf is the questionnaire

Note: The figs folder is empty because the figures generated are a bit too big and many to send through e-mail