PHYS 410: Homework 3 Submission
by Arnold Choa -- 32038144

PDF for answers and write-up can be found in the docs folder:
- CHOA_Honework_3_Answers.pdf

Relevant Code will be found in the code folder:
- q1.py: Contains code for Question 1.
- q2.py: Contains code for Question 2.

Homework_3_Questions.pdf is the questionnaire for reference