PHYS 410: Homework 2 Submission
by Arnold Choa -- 32038144

PDF for answers and write-up can be found in the docs folder:
- CHOA_Honework_2_Answers.pdf

Relevant Code will be found in the code folder:
- q1.py: Contains code for sequence generation. I use the Decimal datatpye for added precision rather than floats.
- q2.py: Contains code for finding the property of the system of equations. I also used the numpy.linalg library to find condition numbers.

Homework_2_Questions.pdf is the questionnaire for reference