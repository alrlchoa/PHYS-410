PHYS 410: Project 2 Submission
by Arnold Choa -- 32038144

PDF for answers and write-up can be found in the docs folder:
- CHOA_Project_2_Answers.pdf

Relevant Code will be found in the code folder:
- ising2D.py: Contains code for 2D Ising Model
- main.py: Contains code for calling isind2D for various parameters

Project_2_Questions.pdf is the questionnaire