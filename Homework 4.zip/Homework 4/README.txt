PHYS 410: Homework 4 Submission
by Arnold Choa -- 32038144

PDF for answers and write-up can be found in the docs folder:
- CHOA_Honework_4_Answers.pdf

Relevant Code will be found in the code folder:
- RK4.py: Contains code for Homework 4. Sections are parsed with comments

Homework_3_Questions.pdf is the questionnaire for reference